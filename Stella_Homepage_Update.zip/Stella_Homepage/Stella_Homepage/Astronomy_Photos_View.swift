//
//  Astronomy_Photos_View.swift
//  Stella_Homepage
//
//  Created by Programmer on 4/13/26.
//

import SwiftUI

struct Item: Identifiable {
    let id = UUID()
    let name: String
    let category: Category
}


struct Astronomy_Photos_View: View {
  
    
    var body: some View {
        NavigationStack {
            ZStack{
                Color("BackgroundColor")
                    .ignoresSafeArea()
                VStack(alignment: .center, spacing: 30) {
                    Text("My Astronomy Photos")
                        .font(.largeTitle)
                        .foregroundColor(.white)
                    
                    
                    
                    
                        .toolbar {
                            ToolbarItem(placement: .principal) {
                                HStack() {
                                    Image("Logo")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width:50, height:50)
                                        
                                    Text("Stellasphere")
                                        .font(.title)
                                        .foregroundColor(.white)
                                        .multilineTextAlignment(.center)
                        
                        
                                }
                            }
                        }
                }
            }
        }
    }
}

#Preview {
    Astronomy_Photos_View()
}
