//
//  Constellation_List_View.swift
//  Stella_Homepage
//
//  Created by Programmer on 4/13/26.
//

import SwiftUI

struct Constellation_List_View: View {
    @State private var searchText: String = ""
    
    let constellations = ["Andromeda", "Antila", "Apus", "Aquarius", "Aquila", "Ara", "Aries", "Auriga", "Boötes", "Caelum", "Camelopardalis", "Cancer", "Canes Venatici", "Canis Major", "Canis Minor", "Capricornus", "Carina","Cassiopeia", "Centaurus", "Cepheus", "Cetus", "Chamaeleon", "Circinus", "Columba", "Coma Berenices", "Corona Australis", "Corona Borealis", "Corvus", "Crater", "Crux", "Cygnus", "Delphinus", "Dorado", "Draco", "Equuleus", "Eridanus", "Gemini", "Leo", "Leo Minor", "Lepus", "Libra", "Lupus", "Lynx", "Mensa", "Microscopium", "Monoceros", "Musca", "Norma", "Octans", "Ophiuchus", "Orion", "Pavo", "Pegasus", "Perseus", "Phoenix", "Pictor", "Pices", "Piscis Austrinus", "Puppis", "Pyxis", "Reticulum", "Sagitta", "Sagittarius", "Scorpius", "Sculptor", "Scutum", "Serpens", "Sextans", "Taurus", "Telescompium", "Triangulum", "Triangulum Australe", "Tucana", "Ursa Major", "Ursa Minor", "Vela", "Virgo", "Volans", "Vulpecula"]
    
    var body: some View {
       
        NavigationStack {
            ZStack{
                Color("BackgroundColor")
                    .ignoresSafeArea()
                VStack(alignment: .center, spacing: 30) {
                    Text("The 88 Constellations")
                        .font(.largeTitle)
                        .foregroundColor(.white)
                        //.navigationTitle("Screen 1")
                    
                    List {
                        ForEach(filteredItems, id: \.self) { item in Text(item)
                        }
                    }
                    .frame(width: 340.0, height: 520.0)
                    .searchable(text: $searchText, prompt: "Search")
                    
                    .toolbar {
                        ToolbarItem(placement: .principal) {
                            HStack() {
                                Image("Logo")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width:50, height:50)
                                    
                                Text("Stellasphere")
                                    .font(.title)
                                    .foregroundColor(.white)
                                    .multilineTextAlignment(.center)
                                    .padding(.vertical, 5.0)
                    
                    
                            }
                        }
                    }
                    
                    
                    
    
                    
                    
                }
            }
        }
        
    }
    var filteredItems: [String] {
        if searchText.isEmpty {
            return constellations
        } else {
            return constellations.filter { $0.localizedCaseInsensitiveContains(searchText)}
        }
    }
        }

#Preview {
    Constellation_List_View()
}
