//
//  Moon_Phase_View.swift
//  Stella_Homepage
//
//  Created by Programmer on 4/13/26.
//

import SwiftUI

struct Moon_Phase_View: View {
    var body: some View {
        NavigationStack {
            ZStack{
                Color("BackgroundColor")
                    .ignoresSafeArea()
                VStack(alignment: .center, spacing: 30) {
                    Text("Moon Phase Tracker")
                        .font(.largeTitle)
                        .foregroundColor(.white)
                    
                    
                        .toolbar {
                            ToolbarItem(placement: .principal) {
                                HStack() {
                                    Image("Logo")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width:50, height:50)
                                        
                                    Text("Stellasphere")
                                        .font(.title)
                                        .foregroundColor(.white)
                                        .multilineTextAlignment(.center)
                        
                        
                                }
                            }
                        }
                }
            }
        }
    }
}

#Preview {
    Moon_Phase_View()
}
