//
//  Moon_Phase_View.swift
//  Stellasphere_Final
//
//  Created by Programmer on 4/29/26.
//

import SwiftUI
//import TinyMoon

struct Moon_Phase_View: View {
    @State private var selectedDate = Date()
//    private var moon: Moon {
//        TinyMoon.calculateMoonPhase(for: selectedDate)
//    }
    
    var body: some View {
        NavigationStack {
            ZStack{
                Color("BackgroundColor")
                    .ignoresSafeArea()
                VStack(alignment: .center, spacing: 30) {
                    
//                    VStack{
                        Text(selectedDate, style: .date)
//                        Text(moon.emoji)
//                        Text(moon.name)
//                        Text("Illumination: \(moon.illuminatedFraction)")
//                        Text("\(moon.ageOfMoon.days) days, \(moon.ageOfMoon.hours) hours, \(moon.ageOfMoon.minutes) minutes")
//                        Text("Full Moon in \(moon.daysTillFullMoon) days")
//                        Text("New Moon in \(moon.daysTillNewMoon) days")
//                    }
                    
                    DatePicker("Select Date", selection: $selectedDate, displayedComponents: .date)
//                        .onChange(of: selectedDate) { newDate in
//                            let calculator = MoonPhaseCalculator()
//                            moonPhase = claculator.calculate(for: newDate)
//                        }
                        .datePickerStyle(.graphical)
                        .padding()
                        .foregroundColor(Color.white)
                    
                        
                    
                   // Text("Moon Phase: \(moonPhase(for: selectedDate))")
                    
                    
                    
                    
                    
                        .toolbar {
                            ToolbarItem(placement: .principal) {
                                HStack() {
                                    Image("Logo")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width:50, height:50)
                                    
                                    Text("Stellasphere")
                                        .font(.title)
                                        .foregroundColor(.white)
                                        .multilineTextAlignment(.center)
                                    
                                    
                                }
                            }
                        }
                }
                
                .foregroundColor(.white)
            }
        }
        
        
    }
//    public enum TinyMoon {
//      public static func calculateMoonPhase(
//        _ date: Date = Date(),
//        timeZone: TimeZone = TimeZone.current)
//        -> Moon
//      {
//        Moon(date: date, timeZone: timeZone)
//      }
//
//      public static func calculateExactMoonPhase(_ date: Date = Date()) -> ExactMoon {
//        ExactMoon(date: date)
//      }
//    }

//    func moonPhase(for date: Date) -> String {
//        let phase = TinyMoon(date: date).phase
//        return "\(phase)"
//    }
}



#Preview {
    Moon_Phase_View()
}
