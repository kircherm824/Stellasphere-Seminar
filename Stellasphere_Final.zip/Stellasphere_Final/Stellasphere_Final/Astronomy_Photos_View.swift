//
//  Astronomy_Photos_View.swift
//  Stellasphere_Final
//
//  Created by Programmer on 4/29/26.
//

import PhotosUI
import SwiftUI

struct GalleryItem: Identifiable {
    let id = UUID()
    let image: Image
    let tags: String
}

struct Astronomy_Photos_View: View {
    @State private var galleryItems: [GalleryItem] = []
    @State private var selectedItem : PhotosPickerItem?
    @State private var loadedImage: Image?
    @State private var tempTags: String = ""
    @State private var showingUploadSheet = false
    
    
    var body: some View {
        NavigationStack {
            ZStack{
                Color("BackgroundColor")
                    .ignoresSafeArea()
                VStack(alignment: .center, spacing: 30) {
                    Text("My Astronomy Photos")
                        .font(.largeTitle)
                        .foregroundColor(.white)
                    
                    Spacer()
                   
                    // Photo Gallery Layout
                    ScrollView {
                        LazyVGrid(columns: [GridItem(.adaptive(minimum: 150))], spacing: 20) {
                            ForEach(galleryItems) { item in
                                VStack {
                                    item.image
                                        .resizable()
                                        .scaledToFill()
                                        .frame(width: 150, height: 150)
                                        .clipped()
                                    Text(item.tags)
                                        .font(.caption)
                                        .foregroundColor(.white)
                                }
                            }
                        }
                        .padding()
                        
                    }
                    .toolbar {
                        Button {
                            showingUploadSheet = true
                        } label: {
                            Image(systemName: "plus.circle.fill")
                                .font(.title)
                        }
                    }
                    .sheet(isPresented: $showingUploadSheet) {
                        VStack(spacing: 20) {
                            PhotosPicker("Select Photo", selection: $selectedItem, matching: .images)
                                .buttonStyle(.bordered)
                            
                            if let loadedImage {
                                loadedImage
                                    .resizable()
                                    .scaledToFit()
                                    .frame(height: 200)
                            }
                            
                            TextField("Enter tags (comma seperated)", text: $tempTags)
                                .textFieldStyle(.roundedBorder)
                                .padding(.horizontal)
                            
                            Button("Upload Photo") {
                                if let loadedImage {
                                    galleryItems.append(GalleryItem(image: loadedImage, tags: tempTags))
                                    
                                    tempTags = ""
                                    selectedItem = nil
                                    self.loadedImage = nil
                                    showingUploadSheet = false
                                }
                            }
                            .disabled(loadedImage == nil)
                        }
                        .padding()
                        .onChange(of: selectedItem) { newItem in
                            Task {
                                if let data = try? await newItem?.loadTransferable(type: Data.self),
                                   let uiImage = UIImage(data: data) {
                                    loadedImage = Image(uiImage: uiImage)
                                }
                            }
                        }
                    }
                   
                    .toolbar {
                        ToolbarItem(placement: .principal) {
                            HStack() {
                                Image("Logo")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width:50, height:50)
                                
                                Text("Stellasphere")
                                    .font(.title)
                                    .foregroundColor(.white)
                                    .multilineTextAlignment(.center)
                                
                                
                            }
                        }
                    }
                }
            }
        }
        
    }
    
   
}


#Preview {
    Astronomy_Photos_View()
}

