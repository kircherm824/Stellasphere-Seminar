//
//  Stellasphere_FinalApp.swift
//  Stellasphere_Final
//
//  Created by Programmer on 4/29/26.
//

import SwiftUI

@main
struct Stellasphere_FinalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
