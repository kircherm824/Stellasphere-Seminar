//
//  ContentView.swift
//  Stellasphere_Final
//
//  Created by Programmer on 4/29/26.
//

import SwiftUI
import UIKit

struct ContentView: View {
    init() {
        
        UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor: UIColor.white, .font: UIFont.systemFont(ofSize: 20, weight: .heavy)]
        
        UINavigationBar.appearance().titleTextAttributes = [.foregroundColor: UIColor.white, .font: UIFont.systemFont(ofSize: 20, weight: .heavy)]
        
        UINavigationBar.appearance().backIndicatorImage = UIImage(systemName: "house")
        UINavigationBar.appearance().backIndicatorTransitionMaskImage = UIImage(systemName: "house")
        
        UINavigationBar.appearance().tintColor = .white
    }
    
    @State private var username: String = ""
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color("BackgroundColor")
                    .ignoresSafeArea()
                
                
                VStack(alignment: .center, spacing: 30) {
                    
                    
                    Text("Welcome, \(username)!")
                        .font(.title)
                        .foregroundColor(.white)
                    
                    //Navigates to the page of the list of constellations
                    NavigationLink(destination: Constellation_List_View()) {
                        Image("Constellation_List")
                            .resizable()
                            .scaledToFit()
                            .frame(width:100, height: 100)
                            .cornerRadius(12)
                            .shadow(radius:5)
                    }
                    Text("List of Constellations")
                        .font(.headline)
                        .foregroundColor(Color.white)
                    
                    
                    //Navigates to the moon phase tracker page
                    NavigationLink(destination: Moon_Phase_View()) {
                        Image("Moon_Tracker")
                            .resizable()
                            .scaledToFit()
                            .frame(width:100, height: 100)
                            .cornerRadius(12)
                            .shadow(radius:5)
                    }
                    Text("Moon Phase Tracker")
                        .font(.headline)
                        .foregroundColor(Color.white)
                    
                    
                    //Navigates to the astronomy photos page
                    NavigationLink(destination: Astronomy_Photos_View()) {
                        Image("My_Photos")
                            .resizable()
                            .scaledToFit()
                            .frame(width:100, height: 100)
                            .cornerRadius(12)
                            .shadow(radius:5)
                        
                    }
                    Text("My Astronomy Photos")
                        .font(.headline)
                        .foregroundColor(Color.white)
                    
                }
                
                .padding()
                
                .toolbar {
                    ToolbarItem(placement: .principal) {
                        HStack() {
                            Image("Logo")
                                .resizable()
                                .scaledToFit()
                                .frame(width:50, height:50)
                                
                            Text("Stellasphere")
                                .font(.title)
                                .foregroundColor(.white)
                                .multilineTextAlignment(.center)
                                .padding(.vertical, 5.0)
                
                
                        }
                    }
                }
                
            
                
            }
            
        }
        
    }
}

#Preview {
    ContentView()
}
