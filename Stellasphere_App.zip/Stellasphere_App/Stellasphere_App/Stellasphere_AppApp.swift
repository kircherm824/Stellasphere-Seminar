//
//  Stellasphere_AppApp.swift
//  Stellasphere_App
//
//  Created by Programmer on 3/18/26.
//

import SwiftUI

@main
struct Stellasphere_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
