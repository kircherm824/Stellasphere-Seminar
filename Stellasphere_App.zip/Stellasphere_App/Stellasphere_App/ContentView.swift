//
//  ContentView.swift
//  Stellasphere_App
//
//  Created by Programmer on 3/18/26.
//

import SwiftUI

struct ContentView: View {
    @State var username: String = ""
    
    var body: some View {
      
            VStack(alignment: .leading, spacing: 15) {
                Spacer()
                
                TextField("Username", text: $username)
                    .padding(10)
                    .overlay {
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(.blue, lineWidth: 2)
                    }
                    .padding(.horizontal)
                
                Spacer()
            }
            .padding()
        }
    }
}

#Preview {
    ContentView()
}
