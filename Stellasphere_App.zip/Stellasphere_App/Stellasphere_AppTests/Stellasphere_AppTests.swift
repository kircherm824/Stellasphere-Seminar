//
//  Stellasphere_AppTests.swift
//  Stellasphere_AppTests
//
//  Created by Programmer on 3/18/26.
//

import Testing
@testable import Stellasphere_App

struct Stellasphere_AppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
