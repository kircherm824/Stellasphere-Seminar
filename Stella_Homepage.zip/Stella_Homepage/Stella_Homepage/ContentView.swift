//
//  ContentView.swift
//  Stella_Homepage
//
//  Created by Programmer on 3/23/26.
//

import SwiftUI
import UIKit

struct ContentView: View {
    init() {
        
        UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor: UIColor.white, .font: UIFont.systemFont(ofSize: 30, weight: .heavy)]
        
        UINavigationBar.appearance().titleTextAttributes = [.foregroundColor: UIColor.white, .font: UIFont.systemFont(ofSize: 30, weight: .heavy)]
    }
    
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color("BackgroundColor")
                    .ignoresSafeArea()
                
                
                VStack(alignment: .center, spacing: 30) {
                    
                    //Navigates to the page of the list of constellations
                    NavigationLink(destination: Constellation_List_View()) {
                        Image("Constellation_List")
                            .resizable()
                            .scaledToFit()
                            .frame(width:100, height: 100)
                            .cornerRadius(12)
                            .shadow(radius:5)
                    }
                    Text("List of Constellations")
                        .font(.headline)
                        .foregroundColor(Color.white)
                        
                    
                    //Navigates to the moon phase tracker page
                    NavigationLink(destination: Moon_Phase_View()) {
                        Image("Moon_Tracker")
                            .resizable()
                            .scaledToFit()
                            .frame(width:100, height: 100)
                            .cornerRadius(12)
                            .shadow(radius:5)
                    }
                    Text("Moon Phase Tracker")
                        .font(.headline)
                        .foregroundColor(Color.white)
                    
                    
                    //Navigates to the astronomy photos page
                    NavigationLink(destination: Astronomy_Photos_View()) {
                        Image("My_Photos")
                            .resizable()
                            .scaledToFit()
                            .frame(width:100, height: 100)
                            .cornerRadius(12)
                            .shadow(radius:5)
                        
                    }
                    Text("My Astronomy Photos")
                        .font(.headline)
                        .foregroundColor(Color.white)
                    
                }
                
                .padding()
                .navigationTitle("Stellasphere")
                .toolbar {
                    ToolbarItem(placement: .principal) {
                        HStack {
                            Image("Logo")
                                .resizable()
                                .scaledToFit()
                                .frame(width:50, height:50)
                        }
                    }
                }
                
                
                
            }
        }
        
    }
}

struct Constellation_List_View: View {
    var body: some View {
        Text("List of Constellations")
            .font(.largeTitle)
            .navigationTitle("Screen 1")
    }
}

struct Moon_Phase_View: View {
    var body: some View {
        Text("Moon Phase Tracker")
            .font(.largeTitle)
            .navigationTitle("Screen 2")
    }
}

struct Astronomy_Photos_View: View {
    var body: some View {
        Text("My Astronomy Photos")
            .font(.largeTitle)
            .navigationTitle("Screen 3")
    }
}
#Preview {
    ContentView()
}
