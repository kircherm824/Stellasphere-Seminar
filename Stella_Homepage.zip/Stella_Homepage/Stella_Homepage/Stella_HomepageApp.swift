//
//  Stella_HomepageApp.swift
//  Stella_Homepage
//
//  Created by Programmer on 3/23/26.
//

import SwiftUI

@main
struct Stella_HomepageApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
