//
//  Stella_HomepageTests.swift
//  Stella_HomepageTests
//
//  Created by Programmer on 3/23/26.
//

import Testing
@testable import Stella_Homepage

struct Stella_HomepageTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
