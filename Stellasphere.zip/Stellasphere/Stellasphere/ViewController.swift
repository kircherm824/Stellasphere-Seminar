import UIKit

struct Constellation {
    let constellationName: String
    let constellationDescription: String
    let constellationStars: String
    let imageName: String
}

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var tableView: UITableView!
    
    
    var constellations: [Constellation] = [
        Constellation(
            constellationName: "Andromeda",
            constellationDescription: "Represents the daughter of Cepheus and Cassiopeia, the princess Andromeda. It is one of the 48 constellations described by the Greek astronomer Ptolemy. The constellation contains the Andromeda Galaxy, the nearest full-fledged galaxy to the Milky Way.",
            constellationStars: "The brightest star in Andromeda is Alpheratz, which represents the head of the constellation at a magnitude of 2.06. The second brightest is Mirach, a red giant, and a magnitude of 2.05. The third brightest star is Almach, a double star with a 5th-magnitude companion 9.7 arcseconds away.",
            imageName: "andromeda-outline"
        ),
        Constellation(
            constellationName: "Antlia",
            constellationDescription: "Represents an early modern vacuum machines. Antlia was created by French astronomer Nicolas-Louis de Lacaille to represent experimental physics.",
            constellationStars: "Antlia is a faint constellation, with its two brightest stars being Alpha Antilae, with a magnitude between 4.22 and 4.29, and Epsilon Antilae, with a magnitude of 4.51. Both stars are near the end of their lives.",
            imageName: "antlia-outline"
            
        ),
        Constellation(
            constellationName: "Apus",
            constellationDescription: "Represents the bird of paradise and means \"without feet\". Apus is a small and relatively faint constellation in the far southern sky, and is only within 7 degrees of the south celestial pole. It first appeared on a celestial globe created by Petrus Plancius in 1598.",
            constellationStars: "The brightest stars are Alpha Apodis, with a magnitude of 3.8 and an orange giant. Beta Apodis, with a magnitude of 4.2 and is also an orange giant. Finally, Delta Apodis, which is a double star with the two component by 103 arcseconds.",
            imageName: "apus-outline"
            
        ),
        Constellation(
            constellationName: "Aquarius",
            constellationDescription: "Is one of the constellations of the zodiac. Represents the \"water carrier\", and is located in a part of the sky called the Sea because of other water based constellations in the area. Aquarius is a very old constellation first appearing in Babylonian star catalogues and later listed by Ptolemy in the second century.",
            constellationStars: "It is not a very bright constellation with it's brightest star being Sadalsuud (Beta Aquarii), with a magnitude of 2.91. Sadalmelik (Alpha Aquarii) is very close in brightness at magnitude 2.94.",
            imageName: "aquarius-outline"
        ),
        Constellation(
            constellationName: "Aquila",
            constellationDescription: "This was a Babylonian constellation, connected to an old myth about a king who watches the world from above riding an eagle. It has also been interpreted as the bird who carries the souls of the dead to heaven due to it being next to the constellation \"The Corpse\".",
            constellationStars: " It's brightest star is Altair, with a magnitude of 0.76 making it one of the brightest stars in the sky. The second-brigthest star is Tarazed, with a magnitude of about 2.7, and an orange giant.",
            imageName: "aquila-outline"
        ),
        Constellation(
            constellationName: "Ara",
            constellationDescription: "One of 48 constellations described by Ptolemy. Represents the altar on which the Greek Gods forged an alliance against the Titans. Ara is sometimes seen as a super constellation along with Lupus and Centaurus.",
            constellationStars: "The two brightest stars are Beta Arae with a magnitude of 2.80, and Alpha Arae with a magnitude of 2.97.",
            imageName: "ara-outline"
        ),
        Constellation(
            constellationName: "Aries",
            constellationDescription: "Is one of the constellations of the zodiac. Aries is also one of the 48 constellation described by Ptolemy, and was depicted as a Hired Man in Babylonian times.",
            constellationStars: "Aries is considered a dim constellation, it's brightest star called Hamal that has a magnitude of 2.0 and is 66 light-years from Earth. It's second-brightest star is Sheratan which has a visual magnitude of 2.6 and lies at 58 light-years.",
            imageName: "aries-outline"
        ),
        Constellation(
            constellationName: "Auriga",
            constellationDescription: "Auriga is a constellation that was confusing to even Hellenistic Greek authors. It was considered to be a charioteer carrying a goat and her offspring.",
            constellationStars: "The brightest star is Capella, the She-Goat, and is one of the six stars in the asterism known as the Winter Hexagon. Capella is the sixth-brighteest star in the sky at 43 light-years. Menakalinan is a star at a magnitude of 1.90 and is 81 light years away. Hasseleh is an orange giant at a magnitude of 2.7 at a distance of 494 light-years.",
            imageName: "auriga-outline"
        ),
        Constellation(
            constellationName: "Boötes",
            constellationDescription: "Is one of 48 constellations described by Ptolemy. It represents a \"ploughman/herdsman\" or ox driver. It is the 13th largest constellation in the sky.",
            constellationStars: " It's bright star is Arcturus, one of the brightest stars at a magnitudde of -0.05, about 37 light-years from Earth. Muphrid ( Eta Boötis) is at a magnitude of 2.68 and lies 37 light-years away. Nekkar (Beta Boötis) is at a magnitude of 3.5.. Izar (Epsilon Boötis) is at a magnitude of 2.37, and a triple star system.",
            imageName: "bootes-outline"
        ),
        Constellation(
            constellationName: "Caelum",
            constellationDescription: "Was invented in the 1750s by Nicolas Louis de Lacaille. The constellationName means 'The Chisel'. It has no mythological origin.",
            constellationStars: "The brightest star is Alpha Caeli, at a magnituted of 4.52, with the second brightest being Gamma Caeli, at a magnitude of 4.62.",
            imageName: "caelum-outline"
        ),
        Constellation(
            constellationName: "Camelopardalis",
            constellationDescription: "Was invented in 1612 by Petrus Plancius. The constellationName comes from camel and leopard due to its spotted pattern.",
            constellationStars: "The brightest star is Beta Cam, a double star with a magnitude of 4.03. The next-brightest are CS Cam and Alpha Cam at a magnitude 4.21 and 4.3. Alpha Cam is one of the most distant stars at over 6000 light-years away.",
            imageName: "camelopardalis-outline"
        ),
        Constellation(
            constellationName: "Cancer",
            constellationDescription: "Is one of the constellations of the Zodiac. Represents a crab from Greek mythology sent by Hera during Heracles’ battle with Hydra.",
            constellationStars: "The brightest star is Altarf or Beta Cancri, at a magnitude of 3.76. It is a double star with a K-type giant star and its faint red dwarf. The next-brightest stars are Delta Cancri at a magnitude of 4.17, Iota Cancri at a magnitude of 4.20, and Alpha Cancri at a magnitude of 4.27.",
            imageName: "cancer-outline"
        ),
        Constellation(
            constellationName: "Canes Venatici",
            constellationDescription: "Invented in 1687 by Johannes Hevelius. Represents two hunting dogs following Boötes and Ursa Major.",
            constellationStars: "The brightest star is 'Cor Caroli', Heart of Charles, in honor to British monarchy. It was named after a time of 11 years when Britain had no king in the 1660s. It has a magnitude of 2.9.",
            imageName: "canesvenatici-outline"
        ),
        Constellation(
            constellationName: "Canis Major",
            constellationDescription: "Included in Ptolemy's 48 constellations. Represents the \"Greater Dog\" following Orion.", constellationStars: "The brightest star is Sirius, also the brightest star in the night sky at a magnitued of -1.46.",
            imageName: "canismajor-outline"
        ),
        Constellation(
            constellationName: "Canis Minor",
            constellationDescription: "Means \"Lesser Dog\". It is associated with Orion’s smaller hunting dog and contains one of the brightest stars in the sky.", constellationStars: "The brightest stars are procyon (Alpha Canis Minoris) at a magnitude of 0.34, and Gomeisa (Beta Canis Minoris) at a magnitude of 2.9.",
            imageName: "canisminor-outline"
        ),
        Constellation(
            constellationName: "Capricornus",
            constellationDescription: "One of the zodiac constellations. Represents a sea-goat, half goat and half fish, from Babylonian mythology.", constellationStars: "It is a faint constellation, having only one star brighter than 3rd magnitude. The brightest star is Deneb Algedi, a 2.9-magnitude star located 39 light-years from Earth. Dabih is a double star withe a primary (Beta Capricorni A) a magnitude of 3.1 and the companion (Beta Capricorni B) a magnitude of 6.1. Nashira is a magnitude of 3.7 and 139 light-years away.",
            imageName: "capricornus-outline"
        ),
        Constellation(
            constellationName: "Carina",
            constellationDescription: "Latin for the keel of a ship. Originally part of Argo Navis before being split into three constellations.", constellationStars: "The brightest star is Canopus, whichi is the second-brightest star in the sky at a visual magnitude of -0.72. Canopus is a white giant about 313 light-years away, it is also 10,000 times brighter than our Sun. Miapladicus is a mgnitude of 1.7 and is 111 light-years from Earth.",
            imageName: "carina-outline"
        ),
        Constellation(
            constellationName: "Cassiopeia",
            constellationDescription: "Represents a queen in Greek mythology who boasted about her beauty and was punished by Poseidon.", constellationStars: "The brightest stars are denoted as Alpha, Beta, Gamme, Delta, and Epsilon. Alpha is known as Schedar, Beta is Caph, and Delta is Rukbat.",
            imageName: "cassiopeia-outline"
        ),
        Constellation(
            constellationName: "Centaurus",
            constellationDescription: "A large southern constellation representing the mythological half-human, half-horse centaur.", constellationStars: "Centaurus has several bright stars, Alpha Centauri being one of the most famous ones. It is a triple star system containing a binairy pairy, which is orbited by the third star, Proxima Centauri. It has a combined magnitude of -0.28, located 4.4 light-years from Earth. Proxima is the closest star to Earth, but due to it being a faint red dwarf it is not visible to the naked eye.",
            imageName: "centaurus-outline"
        ),
        Constellation(
            constellationName: "Cepheus",
            constellationDescription: "Represents King Cepheus of Ethiopia, husband of Cassiopeia and father of Andromeda.",
            constellationStars: "The bright star Delta Cephei is a variable star that ranges at a magnitude of 3.5 to 4.4. It is the prototype Cepheid variable star, which is a class of star which the period of its pulsations directly relates to its mass and therefor absolute brightness.",
            imageName: "cepheus-outline"
        ),
        Constellation(
            constellationName: "Cetus",
            constellationDescription: "Represents a sea monster sent by Poseidon in Greek mythology, defeated by Perseus.",
            constellationStars: "The bright stars are Diphda (Beta Ceti) at a magnitude of 2.24, Baten Kaitos (Zeta Ceti) at a magnitude of 3.92, and Menkar (Alpha Ceti) at a magnitude of 2.82.",
            imageName: "cetus-outline"
        ),
        Constellation(
            constellationName: "Chamaeleon",
            constellationDescription: "Named by Dutch navigators after the chameleon animal found in the southern hemisphere.",
            constellationStars: "The brightest stars are Alpha, Gamma, and Beta Chamaeleontis. The magnitudes being 4.08, 4.10, and 4.38, being quite similar in their brightness.",
            imageName: "chamaeleon-outline"
        ),
        Constellation(
            constellationName: "Circinus",
            constellationDescription: "Represents a drafting compass and was created by Lacaille in the 18th century.",
            constellationStars: "The brightest stars are Alpha Circini with a magnitude of 3.41, Beta Circini with a magnitude of 4.16, and Gamma Circini with a magnitude of 4.51.",
            imageName: "circinus-outline"
        ),
        Constellation(
            constellationName: "Columba",
            constellationDescription: "Represents Noah’s dove from the biblical story of the Ark.",
            constellationStars: "The brightest star is Alpha Columbae (know by its Arabic name Phact), it is a blue-white star about 268 light-years from Earth.",
            imageName: "columba-outline"
        ),
        Constellation(
            constellationName: "Coma Berenices",
            constellationDescription: "Represents Queen Berenice II’s sacrificed hair, turned into a constellation.",
            constellationStars: "Beta Comae Berenices is the brightest star at a magnitude of 4.2. Alpha Comae Berenices is a binary star at a magnitude of 4.3. Gamma Comae Berenices is an orange star at a magnitude of 4.36.",
            imageName: "comaberenices-outline"
        ),
        Constellation(
            constellationName: "Corona Australis",
            constellationDescription: "Means 'Southern Crown', representing a crown or wreath in the southern sky.",
            constellationStars: "The brightest star is Meridiana which has a magnitude of 4.1. Beta Coronae Australis is an orange giant at a magnitude of 4.11. Gamma Coronae Australis is at magnitude of 4.2, and is a tight double star seperated only by 1.3 arcseconds.",
            imageName: "coronaaustralis-outline"
        ),
        Constellation(
            constellationName: "Corona Borealis",
            constellationDescription: "Means 'Northern Crown', representing a crown given in Greek mythology.",
            constellationStars: "The brightest star is Alpha Coronae Borealis, commonly known as Alphecca, at a magnitude of 2.2. Beta Coronoae Borealis is a spectroscopic binary star that is a magnitude of 3.7.",
            imageName: "coronaborealis-outline"
        ),
        Constellation(
            constellationName: "Corvus",
            constellationDescription: "Represents a crow associated with Apollo in Greek mythology.",
            constellationStars: "The brightest star is Gienah (Gamma Corvi) at a magnitude of 2.59. Kraz (Beta Corvi) varies at a magnitude of 2.6 to 2.66. Alograb (Delta Corvi) is at a magnitude of 3.1. Minkar (Epsilon Corvi) has a magnitude of 3.02.",
            imageName: "corvus-outline"
        ),
        Constellation(
            constellationName: "Crater",
            constellationDescription: "Represents a cup used by Apollo in Greek mythology.",
            constellationStars: "The brightest star is Delta Crateris, and orange giant at a magnitude of 3.6. Alpha Crateris, known as Alkes and is an orange star at a magnitude of 4.1. Beta Crateris is at a magnitude of 4.5. Gamma Crateris is a double star system and is at a magnitude of 4.06.",
            imageName: "crater-outline"
        ),
        Constellation(
            constellationName: "Crux",
            constellationDescription: "Known as the Southern Cross, important for navigation in the southern hemisphere.",
            constellationStars: "Has several bright stars such as Alpha Crucis, also known as Acrux and is the thirteenth-brightest star in the entire sky, it is a binary star system of two blue-white stars. Beta Crucis, also known as Mimosa, is a blue-white star giant. Gamma Crucis, is sometimes called Gacrux, is a red giant star. Delta Crucis, also known as Imai, is a double star system of a blue-white sequence star and a fainter companion star.",
            imageName: "crux-outline"
        ),
        Constellation(
            constellationName: "Cygnus",
            constellationDescription: "Represents a swan in Greek mythology, often associated with Zeus.",
            constellationStars: "The bright stars are Alpha Cygni, called Deneb, at a magnitude of 1.25. Albireo, also known as Beta Cygni, at a magnitude of 3.21.",
            imageName: "cygnus-outline"
        ),
        Constellation(
            constellationName: "Delphinus",
            constellationDescription: "Represents a dolphin, a messenger of Poseidon in Greek mythology.",
            constellationStars: "The brightest stars are Alpha Delphini, also known as Sualocin at a magnitude of 3.86. Beta Delphini, also known as Rotanev at a magnitude of 3.72. Epsilon Delphini at a magnitude of 3.98. Gamma Delphini at a magnitude of 4.36.",
            imageName: "delphinus-outline"
        ),
        Constellation(
            constellationName: "Dorado",
            constellationDescription: "Named after a swordfish; contains part of the Large Magellanic Cloud.",
            constellationStars: "The brightest stars are Alpha Doradus, a blue-white star at a magnitude of 3.3. Beta Doradus, a Cepheid variable star that ranges at a magnitud of 3.5 to 4.1. ",
            imageName: "dorado-outline"
        ),
        Constellation(
            constellationName: "Draco",
            constellationDescription: "Represents a dragon guarding the golden apples in Greek mythology.",
            constellationStars: "The brightest star is Eltanin, an orange giant at a magnitude of 2.2. Beta Draconis, or Rastaban, a yellow giant at a magnitude of 2.8. Alpha Draconis, or Thuban, a blue-white giant at a magnitude of 3.67.",
            imageName: "draco-outline"
        ),
        Constellation(
            constellationName: "Equuleus",
            constellationDescription: "Represents a small horse or foal in Greek mythology.",
            constellationStars: "The brightest stars are Alpha Equulei, also known as Kitalpha, at a visual magnitude of 3.9. Gamma Equulei, a variable star that changes from a visual magnitude of 4.58 to 4.77 over a period of 12.5 minutes.",
            imageName: "equuleus-outline"
        ),
        Constellation(
            constellationName: "Eridanus",
            constellationDescription: "Represents a river associated with the myth of Phaethon.",
            constellationStars: "The brightest stars are Alpha Eridani, also known as Achernar, is a blue-white giant at a magnitude of 0.445. Beta Eridani, also known as Cursa, is a blue-white star at a magnitude of 2.8. Theta Eridani, also known as Acamar, a double star of two blue-white stars at magnitudes of 3.2 and 4.3.",
            imageName: "eridanus-outline"
        ),
        Constellation(
            constellationName: "Fornax",
            constellationDescription: "Modern constellation meaning 'the furnace', no mythological origin.",
            constellationStars: "The bright stars are Alpha Fornacis, or Dalim, a double star system with a yellow-white star at a magnitude of 3.91 and blue straggler at a magnitude of 6.5. Beta Fornacis, a yellow-white giant star at a magnitude of 4.5. Nu Fornacis, a blue giant at a magnitude of 4.7.",
            imageName: "fornax-outline"
        )
    ]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
    }
    
    //error pointer
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return constellations.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tableCell", for: indexPath)
        cell.textLabel?.text = constellations[indexPath.row].constellationName
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showConstellation" {
            guard let destinationVC = segue.destination as? ConstellationsTableViewController,
                  let indexPath = tableView.indexPathForSelectedRow else { return }

            destinationVC.selectedConstellation = constellations[indexPath.row]
        }
    }
}



