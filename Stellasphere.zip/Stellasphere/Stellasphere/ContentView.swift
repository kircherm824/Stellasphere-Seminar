//
//  SwiftUIView.swift
//  Stellasphere_App
//
//  Created by Programmer on 3/18/26.
//

import SwiftUI

struct ContentView: View {
    
    @State private var username: String = ""
    @State private var password: String = ""
    
    var body: some View {
        
        ZStack  {
            Color("BackgroundColor").ignoresSafeArea(.all)
            
            VStack{
                Spacer()
                Image("stellasphereLogo")
                    .resizable()
                    .frame(width:250, height: 250)
                
                Text("Welcome to \nStellasphere")
                    .font(.custom("Georgia", size: 40))
                    .foregroundColor(Color.white)
                
                Text("Username:")
                    .position(x:100, y:0)
                    .frame(width: 400, height: 20)
                    .foregroundColor(Color(red: 0.929, green: 0.953, blue: 0.945))
           
                TextField("Enter Username", text: $username)
                    .padding(5)
                    .background(Color.white)
                    .position(x: 160, y:0)
                    .frame(width: 300, height: 20)
                    
                Text("Password:")
                    .position(x:100, y:10)
                    .frame(width: 400, height: 20)
                    .foregroundColor(Color(red: 0.929, green: 0.953, blue: 0.945))
                
                TextField("Enter Password", text: $password)
                    .padding(5)
                    .background(Color.white)
                    .position(x: 160, y:10)
                    .frame(width: 300, height: 20)
                
                Spacer()
                
                Button(action: {
                }) {
                    Text("Log In")
                        .position(x:90, y:28)
                        .font(.system(.title))
                        .padding(10)
                        .foregroundColor(.white)
                        .background(Color.blue)
                        .cornerRadius(10)
                        .frame(width: 200, height: 75)
                }
                
                Spacer()
                
                Button(action: {
                }) {
                    Text("Register")
                        .position(x:45, y:12)
                        .padding(10)
                        .foregroundColor(.black)
                        .background(Color.white)
                        .cornerRadius(10)
                        .frame(width: 110, height: 45)
                }
                
                Spacer()
                
            }
        }
    }
}

#Preview {
    ContentView()
}
