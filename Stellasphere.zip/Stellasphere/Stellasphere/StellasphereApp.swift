//
//  StellasphereApp.swift
//  Stellasphere
//
//  Created by Programmer on 3/23/26.
//

import SwiftUI

@main
struct StellasphereApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
