
import UIKit

class ConstellationsTableViewController: UIViewController {
    
    var selectedConstellation: Constellation? {
            didSet {
                updateUI()
            }
        }
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var starsLabel: UILabel!
    @IBOutlet weak var imageName: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI()
    }
    

    private func updateUI() {
        guard isViewLoaded else { return }

        if let constellation = selectedConstellation {
            nameLabel.text = constellation.constellationName
            descriptionLabel.text = constellation.constellationDescription
            starsLabel.text = constellation.constellationStars
            imageName.image = UIImage (named: constellation.imageName)

        } else {
            nameLabel.text = "DISCONNECTED"
            descriptionLabel.text = "DISCONNECTED"
        }
    }
    }
