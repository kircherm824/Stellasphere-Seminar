//
//  Astronomy_Photos_View.swift
//  Stella_Homepage
//
//  Created by Programmer on 4/13/26.
//

import PhotosUI
import SwiftUI



struct Astronomy_Photos_View: View {
    @State private var selectedItem : PhotosPickerItem?
    @State private var selectedImage: UIImage?
    @State private var description = ""
    @State private var tags = ""
    
    
    var body: some View {
        NavigationStack {
            ZStack{
                Color("BackgroundColor")
                    .ignoresSafeArea()
                VStack(alignment: .center, spacing: 30) {
                    Text("My Astronomy Photos")
                        .font(.largeTitle)
                        .foregroundColor(.white)
                    
                    Spacer()
                    NavigationLink(destination: Upload_Photos_View()) {
                        
                    }
                    Form {
                        Section {
                            PhotosPicker(selection: $selectedItem, matching: .images) {
                                if let selectedImage {
                                    Image(uiImage: selectedImage)
                                        .resizable()
                                        .scaledToFit()
                                } else {
                                    Label("Select Photo", systemImage: "photo")
                                }
                            }
                        }
                        Section("Details") {
                            TextField("Description", text: $description, axis: .vertical)
                            TextField("Tags (comma separted)", text: $tags)
                        }
                        
                        Button("Upload Photo") {
                            uploadPhoto()
                        }
                        .buttonStyle(.borderedProminent)
                        .disabled(selectedImage == nil)
                    }
                    .onChange(of: selectedItem) { _ in
                        Task {
                            if let data = try? await selectedItem?.loadTransferable(type: Data.self) {
                                selectedImage = UIImage(data: data)
                            }
                        }
                        
                        
                    }
                    .toolbar {
                        ToolbarItem(placement: .principal) {
                            HStack() {
                                Image("Logo")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width:50, height:50)
                                
                                Text("Stellasphere")
                                    .font(.title)
                                    .foregroundColor(.white)
                                    .multilineTextAlignment(.center)
                                
                                
                            }
                        }
                    }
                }
            }
        }
        
    }
    func uploadPhoto() {
        guard let imageToUpload = selectedImage else { return }
        
        let finalTags = tags.split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces)}
        print("Uploading: \(description), Tags: \(finalTags), Image: \(imageToUpload)")
    }
   
}
#Preview {
    Astronomy_Photos_View()
}



/*
 @State private var processedImage: Image?
 @State private var selectedItem: PhotosPickerItem?
 @State private var description: String = ""
 @State private var tags: [String] = []
 
 
 PhotosPicker(selection: $selectedItem) {
     if let processedImage {
         processedImage
             .resizable()
             .scaledToFit()
     } else {
         ContentUnavailableView("No picture", systemImage: "photo.badge.plus", description: Text("Tap to import a photo"))
             .foregroundColor(.white)
     }
         
 }
 .buttonStyle(.bordered)
 .onChange(of: selectedItem, loadImage)
 
 
 func loadImage() {
     Task {
         guard let imageData = try await selectedItem?.loadTransferable(type: Data.self) else { return}
         guard let inputImage = UIImage(data: imageData) else { return }
     }
 }
 
 
 */


//
//                    PhotosPicker(selection: $pickerItems, maxSelectionCount: 5, matching: .images) {
//                        Label("Select a photo", systemImage: "photo.badge.plus")
//                            .font(.title3)
//                            .buttonStyle(.borderedProminent)
//
//                    }
//
//                    ScrollView {
//                        ForEach(0..<selectedImages.count, id: \.self) { i in
//                            selectedImages[i]
//                                .resizable()
//                                .scaledToFit()
//                        }
//                    }
//                }
//                .onChange(of: pickerItems) {
//                    Task {
//                        selectedImages.removeAll()
//
//                        for item in pickerItems {
//                            if let loadedImage = try await item.loadTransferable(type: Image.self) {
//                                selectedImages.append(loadedImage)
//                            }
//                        }
//
//                    }
                    
                    
                    
                   // TextField("Description", text: $description)
                     //   .textFieldStyle(.roundedBorder)
